import React from 'react'

const StudentDashboard = () => {
  return (
    <div>StudentDashboard</div>
  )
}

export default StudentDashboard